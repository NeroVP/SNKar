#include <path.h>
#include <stdio.h>
int followpath()
{
	int length = (sizeof(path)/sizeof(int)- 1) ;
	printf("%d\n", length);
	int i = path[length];
	int j = path[length-1];
	printf("%d\n", i);
	int coordonnes[16][2] = {
{5,5},
{5,2},
{5,0},
{1,0},
{0,0},
{0,2},
{0,4},
{0,5},
{1,5},
{1,4},
{3,4},
{3,5},
{4,5},
{4,2},
{4,1},
{1,1}
};

	while (length != -1)
	{
		printf("%d (%d,%d)\n", i, coordonnes[i][0], coordonnes[i][0]);
		if ((coordonnes[i][0] == coordonnes[j][0]) && (coordonnes[i][1] < coordonnes[j][1])){
			printf("(%d, %d) move up\n", coordonnes[i][0], coordonnes[i][1]);
			}
		else if ((coordonnes[i][0] < coordonnes[j][0]) && (coordonnes[i][1] == coordonnes[j][1])){
			printf("(%d, %d) move right\n", coordonnes[i][0], coordonnes[i][1]);
			}
		else if ((coordonnes[i][0] > coordonnes[j][0]) && (coordonnes[i][1] == coordonnes[j][1])){
			printf("(%d, %d) move left\n", coordonnes[i][0], coordonnes[i][1]);
			}
		length--;
		i = path[length];
		j = path[length-1];
	}
	if (length == 0)
		printf("stop");
	return 0;
}

int main()
{
	followpath();
}
