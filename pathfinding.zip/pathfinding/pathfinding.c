#include<stdio.h>
#include<stdlib.h>
#define INFINITY 9999
#define n 16

FILE* dijkstra(int cost[n][n],int startnode, int goalnode);

int main()
{
	int sourcenode;
	int goalnode;
	int matrix[n][n] =
  {
  {0,3,0,0,0,0,0,0,0,0,0,0,1,0,0,0},
  {3,0,2,0,0,0,0,0,0,0,0,0,0,1,0,0},
  {0,2,0,4,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,4,0,1,0,0,0,0,0,0,0,0,0,0,1},
  {0,0,0,1,0,2,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,2,0,2,0,0,0,0,0,0,4,0,0},
  {0,0,0,0,0,2,0,1,0,1,0,0,0,0,0,0},
  {0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,1,0,1,0,2,0,0,0,0},
  {0,0,0,0,0,0,1,0,1,0,2,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,2,0,1,0,0,0,0},
  {0,0,0,0,0,0,0,0,2,0,1,0,1,0,0,0},
  {1,0,0,0,0,0,0,0,0,0,0,1,0,3,0,0},
  {0,1,0,0,0,4,0,0,0,0,0,0,3,0,1,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,3},
  {0,0,0,1,0,0,0,0,0,0,0,0,0,0,3,0}
  };

	printf ("There are %d vertexes\n", n);
	printf("\nEnter the source node:");
	scanf("%d",&sourcenode);
	sourcenode--;
	printf("Enter the goal node:");
	scanf("%d", &goalnode);
	goalnode--;
	dijkstra(matrix,sourcenode, goalnode);
	return 0;
}

FILE* dijkstra(int matrix[n][n],int sourcenode, int goalnode)
{
	FILE *file;
	int cost[n][n],distance[n],previous[n],queued[n];
	int count,smallercost,nextnode,j,i, size = 1;

	//previous[] stores the predecessor of each node
	//count gives the number of nodes seen so far
	//creates the cost matrix with infinite values
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			if(matrix[i][j]==0)
				cost[i][j]=INFINITY;
			else
				cost[i][j]=matrix[i][j];

	//initialize previous[],distance[] and queued[]
	for(i=0;i<n;i++)
	{
		distance[i]=cost[sourcenode][i];
		previous[i]=sourcenode;
		queued[i]=0;
	}

	distance[sourcenode]=0;
	queued[sourcenode]=1;
	count=1;

	while(count<n-1)
	{
		smallercost=INFINITY;

		//nextnode gives the node with the minimum distance
		for(i=0;i<n;i++)
			if(distance[i]<smallercost&&!queued[i])
			{
				smallercost=distance[i];
				nextnode=i;
			}

			//check if a better path exists through nextnode
			queued[nextnode]=1;
			for(i=0;i<n;i++)
				if(!queued[i])
					if(smallercost+cost[nextnode][i]<distance[i])
					{
						distance[i]=smallercost+cost[nextnode][i];
						previous[i]=nextnode;
					}
		count++;
	}
	printf("\nThe distance from the source node to the goal node is %d\n", distance[goalnode]);
	j = goalnode;
	do{
		size++;
		j = previous[j];
	}while(j != sourcenode);
	j = goalnode;
	printf("The shortest path is : %d", goalnode+1);
	file = fopen("./path.h", "w+");
	if (file != NULL)
	{
		fprintf(file, "int path[%d] = {%d ", size, goalnode+1);
		do{
			j = previous[j];
			printf(" <- %d", j+1);
			fprintf(file, ", %d", j+1);
		}while(j != sourcenode);
		fprintf(file, "};");
	}
	else
	{
		printf("Erreur dans la cr�ation de path.h, veuillez recommencer.");
		exit(-1);
	}
	
	return file;
}
